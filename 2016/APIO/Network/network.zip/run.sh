#!/bin/sh

./network < network.in

