#!/bin/sh

g++ network.cpp grader.cpp -O2 -static -o network -std=c++11

