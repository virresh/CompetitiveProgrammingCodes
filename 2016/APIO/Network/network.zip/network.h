void findRoute(int N, int a, int b);
int ping (int i, int j);
void travelTo (int k);
