#!/bin/sh

fpc -XS -O2 -onetwork grader.pas

