#!/bin/sh

gcc network.c grader.c -O2 -static -o network -std=c11

